package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.model.Train;
import com.cts.service.TrainService;

@Controller
public class TrainController {
	 @Autowired
	  TrainService trainService;
	private Object railwaystation;
		
		
		@GetMapping(value="/allTrain")
		public ResponseEntity<?> trainList()
		{
			return new ResponseEntity<List<Train>>(trainService.allTrain(),HttpStatus.OK);
		}
		
		@GetMapping(value="/searchTrainById/{id}")
		public ResponseEntity<?> searchTrainById(@PathVariable("id") String id)
		{
			Train s = trainService.searchTrainById(id);
			if(s==null){
				return new ResponseEntity<String>("Train ID not found!!", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<Train>(s,HttpStatus.OK);
		}
		
		
		
		
		@GetMapping(value="/searchTrainBySourceAndDestination/{source}/{destination}")
		public ResponseEntity<?> searchTrainBySourceAndDestination(@PathVariable("source") String source, @PathVariable("destination") String destination )
		{
			List<Train> s = trainService.searchTrainBySourceAndDestination(source,destination);
			if(s.size()==0){
				return new ResponseEntity<String>("No flights found between given locations!!", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<Train>>(s,HttpStatus.OK);
		}
		
		@GetMapping(value="/searchFlightByRailwayline/{railwayline}")
		public ResponseEntity<?> searchTrainByAirline(@PathVariable("railwayline") String airline)
		{
			
			List<Train> s = trainService.searchTrainByRailwaystation((String) railwaystation);
			if(s.size()==0){
				return new ResponseEntity<String>("No train found for given railwaystation!!", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<Train>>(s,HttpStatus.OK);
		}
		
	}



