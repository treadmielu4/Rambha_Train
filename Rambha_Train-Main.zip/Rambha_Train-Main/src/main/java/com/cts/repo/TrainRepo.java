package com.cts.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cts.model.Train;

@Repository
public interface TrainRepo extends CrudRepository<Train, Integer> {

	List<Train> findBySourceAndDestination(String source, String destination);

	Train findByTrainNumber(String string);

	List<Train> findByRailwaystationName(String railwaystation);


}
