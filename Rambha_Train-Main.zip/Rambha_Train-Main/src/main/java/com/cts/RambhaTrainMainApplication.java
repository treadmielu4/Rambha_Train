package com.cts;

import java.text.SimpleDateFormat;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.cts.model.Train;
import com.cts.repo.TrainRepo;

@SpringBootApplication
public class RambhaTrainMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(RambhaTrainMainApplication.class, args);
	}
	@Bean
	CommandLineRunner initDatabase(final TrainRepo repository) {

		final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		return args -> {
			repository.save(new Train(1,"I123", "Pune", "Goa", format.parse("2020-01-01"), 1500, "RajdhaniExpress"));
			repository.save(new Train(2,"I234", "Delhi", "Kolkata", format.parse("2020-02-01"), 2000, "KolkataExpress"));
			repository.save(new Train(3,"V453", "Mumbai", "Hyderabad", format.parse("2020-04-01"), 1800, "SatabdiExpress"));
			repository.save(new Train(4,"G615", "Pune", "Goa", format.parse("2019-04-01"), 2480, "GOAExpress"));
			repository.save(new Train(5,"G582", "Bangalore", "Kolkata", format.parse("2018-04-01"), 1675, "BangloreExpress"));
			repository.save(new Train(6,"J847", "Chennai", "Pune", format.parse("2017-01-01"), 1300, "ChennaiExpress"));
		};

}
}
