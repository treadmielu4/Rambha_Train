package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Train;
import com.cts.repo.TrainRepo;

@Service
public class TrainService {
	@Autowired
	TrainRepo trainRepo;

	public List<Train> allTrain() {
		return (List<Train>) trainRepo.findAll();
	
	}

	public Train searchTrainById(String id) {
		Train s = trainRepo.findByTrainNumber(id);
		if(s==null){
			return null;
		}
		return s;
	
	}

	public List<Train> searchTrainBySourceAndDestination(String source, String destination) {
		return (List<Train>) trainRepo.findBySourceAndDestination(source,destination);	
	
	}

	public List<Train> searchTrainByRailwaystation(String railwaystation) {
		// TODO Auto-generated method stub
		return (List<Train>) trainRepo.findByRailwaystationName(railwaystation);	
	}

	


}
