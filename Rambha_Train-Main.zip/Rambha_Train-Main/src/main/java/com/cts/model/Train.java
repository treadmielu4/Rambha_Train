package com.cts.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "train")
public class Train {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String trainNumber;
	private String source;
	private String destination;
	private Date trainDate;
	private double fare;
	private String railwaystationName;
	
	
	
	public Train() {
		super();
	}
	public Train(int trainId, String trainNumber, String source, String destination, Date trainDate, double fare, String railwaystationName) {
		super();
		this.id = trainId;
		this.trainNumber = trainNumber;
		this.source = source;
		this.destination = destination;
		this.trainDate = trainDate;
		this.fare = fare;
		this.railwaystationName = railwaystationName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getTrainDate() {
		return trainDate;
	}
	public void setTrainDate(Date trainDate) {
		this.trainDate = trainDate;
	}
	public String getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(String trainNumber) {
		this.trainNumber = trainNumber;
	}
	
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRailwayStationName() {
		return railwaystationName;
	}
	public void setAirlineName(String railwaystationName) {
		this.railwaystationName = railwaystationName;
	}

}


